package com.my.samaanasaan.model;

public class User {
    String Name ;
    String userName;
    String userPwd;
    String userPhone;
    String userCnic;

    public void setName(String name) {
        Name = name;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public void setUserCnic(String userCnic) {
        this.userCnic = userCnic;
    }

    public String getName() {
        return Name;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public String getUserCnic() {
        return userCnic;
    }

    public User(String name, String userName, String userPwd, String userPhone, String userCnic) {
        Name = name;
        this.userName = userName;
        this.userPwd = userPwd;
        this.userPhone = userPhone;
        this.userCnic = userCnic;
    }

    public User() {
    }
}
