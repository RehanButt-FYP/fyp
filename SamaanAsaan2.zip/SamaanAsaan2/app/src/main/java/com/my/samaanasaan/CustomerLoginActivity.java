package com.my.samaanasaan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.rilixtech.CountryCodePicker;

public class CustomerLoginActivity extends AppCompatActivity {


    EditText etPhone; //////=== Edit Text in which user enter mobile number
    Button signIn; //////======== Button which is used to intiat verification process
    TextView signUp;//////=========== This TextView act as Button and take user to registration actiivty

    CountryCodePicker codePicker;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_login);





        signIn=findViewById(R.id.SignIn);
        codePicker=findViewById(R.id.ccp);
        etPhone=findViewById(R.id.phone_number_edt);
        signUp=findViewById(R.id.signUp);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent goToRegistration=new Intent(CustomerLoginActivity.this,RegistrationActivity.class);
                startActivity(goToRegistration);
            }
        });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String code = codePicker.getSelectedCountryCode().toString();


                String number=etPhone.getText().toString();

                String phoneNumber;

                if (number!=null) {
                    phoneNumber = "+"+code + number;
                }else
                {
                    etPhone.setError("Please Enter Number");
                    etPhone.requestFocus();
                    return;
                }
                Toast.makeText(CustomerLoginActivity.this, phoneNumber, Toast.LENGTH_LONG).show();

              //  Intent goToVerifyCode=new Intent(CustomerLoginActivity.this, VerifyNumberActivity.class);
               // startActivity(goToVerifyCode);
                 Intent goToVarifyCode = new Intent(CustomerLoginActivity.this,VerifyNumberActivity.class);
                goToVarifyCode.putExtra("PhoneNumber", phoneNumber);
                startActivity(goToVarifyCode);



            }
        });


    }
}
