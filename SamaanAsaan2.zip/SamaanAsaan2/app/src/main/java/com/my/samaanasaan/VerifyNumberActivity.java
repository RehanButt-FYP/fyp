package com.my.samaanasaan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class VerifyNumberActivity extends AppCompatActivity {



    String codeSended; //////====== it saves that code which will send to user
    private ProgressDialog loadingBar;//========This loading bar is used when checking the entered code is correct or not
    Button signIn;//====== This Button is used to intiate the process of Number verification if code is correct, it takes user to next activity
    TextView changeNumber;//=================This Text view is clickable and used to change the Phone  Number
///////////=============Edit Text That contain code===============///////////
    // EditText c1=findViewById(R.id.c1);
    //EditText c2=findViewById(R.id.c2);
    //EditText c3=findViewById(R.id.c3);
    //EditText c4=findViewById(R.id.c4);
    //EditText c5=findViewById(R.id.c5);
    //EditText c6=findViewById(R.id.c6);

    //   FirebaseAuth mAuth;  //////=======Firebase Authentication instance
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_number);

       loadingBar=new ProgressDialog(this);
       changeNumber = findViewById(R.id.ChangeNumber);

        String phoneNumber=getIntent().getStringExtra("PhoneNumber");
        Toast.makeText(VerifyNumberActivity.this, phoneNumber, Toast.LENGTH_LONG).show();
        //   sendVerificatonCode(phoneNumber);
        //  mAuth = FirebaseAuth.getInstance();
        signIn=findViewById(R.id.btnSignIn);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loadingBar.setTitle("Logging in...");
                loadingBar.setMessage("Please wait for a mement this might take a few seconds");
                loadingBar.show();
                Intent goCustomerHome= new Intent(VerifyNumberActivity.this,CustomerMapsActivity.class);
                startActivity(goCustomerHome);
            }
        });


        /////////////=====================On click Listener for Text view for changing the Number============/////////////

        changeNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent goToCustomerLogin=new Intent(VerifyNumberActivity.this,CustomerLoginActivity.class);
                startActivity(goToCustomerLogin);
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }

/*

    private void verifyCode(String code){

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(codeSended, code);
        signInWithCredential(credential);
    }



    private void signInWithCredential(PhoneAuthCredential credential) {


        mAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                {
                    Intent home=new Intent(VerifyNumberActivity.this,HomeActivity.class);
                    home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(home);
                }
                else
                {
                    Toast.makeText(VerifyNumberActivity.this,"Enter Wrong Code" ,Toast.LENGTH_LONG).show();
                }
            }
        });


    }


    private void sendVerificatonCode(String number){

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallBack);
    }


    /////////=====================For mCallBackMethod=========================////////////////////

       private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBack=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
           @Override
           public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
               String code=phoneAuthCredential.getSmsCode();
               if(code!=null)
               {
                   //          c1.setText(code.charAt(0));
                   //        c2.setText(code.charAt(1));
                   //      c3.setText(code.charAt(2));
                   //    c4.setText(code.charAt(3));
                   //  c5.setText(code.charAt(4));
                   //c6.setText(code.charAt(5));
                   //        verifyCode(code);
               }
           }

           @Override
           public void onVerificationFailed(FirebaseException e) {
               Toast.makeText( VerifyNumberActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
           }

           @Override
           public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
               super.onCodeSent(s, forceResendingToken);
               codeSended=s;
           }
       };

*/
}
