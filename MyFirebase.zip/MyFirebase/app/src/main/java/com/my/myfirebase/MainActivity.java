package com.my.myfirebase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase mFirebase;
    DatabaseReference mref;
    Button btnWrite;
    Button btnRead;
    EditText etName;
    EditText etPhone;
    EditText etPwd;
    TextView txtName;
    TextView txtPhone;
    TextView txtPwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirebase=FirebaseDatabase.getInstance();
        mref=mFirebase.getReference();

        btnRead=findViewById(R.id.bt2);
        btnWrite=findViewById(R.id.btn1);

        etName=findViewById(R.id.etname);
        etPhone=findViewById(R.id.etphone);
        etPwd=findViewById(R.id.etpwd);

        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name=etName.getText().toString();
                String phone=etPhone.getText().toString();
                String pwd=etPwd.getText().toString();
                boolean check=true;
               check=  mref.child("Users").child("user3").child("Age").setValue(phone).isSuccessful();
                check=  mref.child("Users").child("user3").child("Name").setValue(name).isSuccessful();

                check=mref.child("Users").child("user3").child("Password").setValue(pwd).isSuccessful();
                if (check) {

                    Toast.makeText(MainActivity.this, "Data added successfully", Toast.LENGTH_LONG).show();
                }
                else
                    {

                        Toast.makeText(MainActivity.this, "Data is Not Added...", Toast.LENGTH_LONG).show();

                    }
                }
        });

    }
}
